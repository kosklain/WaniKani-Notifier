### BunPro Notifier
Creates an icon with the number of available reviews on Bunpro.

Get a notification icon in Chrome when items to review in Bunpro. This extension adds a small icon to the right of the address bar which remains there until you complete your reviews.
